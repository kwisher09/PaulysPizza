// Page Loader


const toppingPrice = {
	cheese: 0,
	pepperoni: 1.00,
	sausage: 1.25,
	bacon: 1.50,
	mushrooms: 0.75,
	onions: 0.50
};

const sizePrice = {
	small: 8.00,
	medium: 10.00, 
	large: 12.50,
	extraLarge: 15.00
}; 	

//Totals price when toppings/sizes are changed 
function pizzaPrice(){
	var sum = 0;
	for(var i = 0; i < arguments.length; i++){
		sum += arguments[i]; 
	}
	return sum; 
} 

const smallCheesePrice = document.getElementById('cheese-small-button'); 
smallCheesePrice.addEventListener('click', function(){
	document.getElementById('cheese-pizza-price').innerHTML = "$" + sizePrice.small.toFixed(2)}, false); 
const mediumCheesePrice = document.getElementById('cheese-medium-button'); 
mediumCheesePrice.addEventListener('click', function(){
	document.getElementById('cheese-pizza-price').innerHTML = "$" + sizePrice.medium.toFixed(2)}, false); 
const largeCheesePrice = document.getElementById('cheese-large-button'); 
largeCheesePrice.addEventListener('click', function(){
	document.getElementById('cheese-pizza-price').innerHTML = "$" + sizePrice.large.toFixed(2)}, false); 

//change size
function changeSizeToSmall(image){
	if (document.getElementById('small').checked == true){
		document.getElementById(image).height = 450; 
		document.getElementById(image).width = 450; 
		document.getElementById('medium').checked = false; 
		document.getElementById('large').checked = false; 
	}
	else{
		document.getElementById(image).height = 475; 
		document.getElementById(image).width = 475; 
	}
	}
function changeSizeToMedium(image){
	if (document.getElementById('medium').checked == true){
		document.getElementById(image).height = 475; 
		document.getElementById(image).width = 475; 
		document.getElementById('small').checked = false; 
		document.getElementById('large').checked = false; 
	}
	else{
		document.getElementById(image).height = 475; 
		document.getElementById(image).width = 475;  
	}
}
function changeSizeToLarge(image){
	if (document.getElementById('large').checked == true){
		document.getElementById(image).height = 500; 
		document.getElementById(image).width = 500; 
		document.getElementById('small').checked = false; 
		document.getElementById('medium').checked = false; 
	}
	else{
		document.getElementById(image).height = 475; 
		document.getElementById(image).width = 475;  
	}
}

//add order-change image
function toggleVisibility(id) {
   var el = document.getElementById(id);
    
   if (el.style.visibility=="visible") { 
          el.style.visibility="hidden";
     }
     else {
          el.style.visibility="visible";
     }
}


//Change Crust Type
function thinSelection(){
	if (document.getElementById('thin').checked == true){
		document.getElementById('hand-tossed').checked = false; 
		document.getElementById('pan').checked = false; 
	}
}
function handTossedSelection(){
	if (document.getElementById('hand-tossed').checked == true){
		document.getElementById('thin').checked = false; 
		document.getElementById('pan').checked = false; 
	}
}

function panSelection(){
	if (document.getElementById("pan").checked == true) {
		document.getElementById('thin').checked = false; 
		document.getElementById('hand-tossed').checked = false; 
	}
}




	

